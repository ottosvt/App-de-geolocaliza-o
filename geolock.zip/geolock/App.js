import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { CheckinsProvider } from './Context/CheckinsContext';
import HomeScreen from './screens/HomeScreen';
import HistoryScreen from './screens/HistoryScreen';

const Stack = createNativeStackNavigator();

const theme = {
  ...DefaultTheme,
  colors: { ...DefaultTheme.colors, background: '#050A18', card: '#050A18', text: '#F2F6FF' },
};

export default function App() {
  return (
    <CheckinsProvider>
      <NavigationContainer theme={theme}>
        <StatusBar style="light" />
        <Stack.Navigator>
          <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
          <Stack.Screen
            name="Historico"
            component={HistoryScreen}
            options={{
              title: 'Meus check-ins',
              headerTintColor: '#F2F6FF',
              headerStyle: { backgroundColor: '#050A18' },
              headerShadowVisible: false,
            }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </CheckinsProvider>
  );
}
