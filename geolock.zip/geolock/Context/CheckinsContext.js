import React, { createContext, useContext, useState } from 'react';

const Ctx = createContext(null);

export function CheckinsProvider({ children }) {
  const [checkins, setCheckins] = useState([]);
  const [current, setCurrent] = useState(null); // última posição conhecida

  const add = (item) => setCheckins((l) => [item, ...l]);
  const remove = (id) => setCheckins((l) => l.filter((c) => c.id !== id));

  return (
    <Ctx.Provider value={{ checkins, add, remove, current, setCurrent }}>
      {children}
    </Ctx.Provider>
  );
}

export const useCheckins = () => useContext(Ctx);