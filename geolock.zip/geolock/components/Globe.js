import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Image, StyleSheet, View } from 'react-native';
import Svg, { Defs, RadialGradient, Stop, Circle } from 'react-native-svg';

// Mapa-múndi equirretangular (2:1). Para trocar, basta mudar a URL.
const EARTH = 'https://threejs.org/examples/textures/planets/earth_atmos_2048.jpg';

/**
 * Globo que gira sozinho. Quando recebe `focus` ({latitude, longitude}),
 * para e centraliza naquele ponto, com um marcador pulsante.
 */
export default function Globe({ size = 320, focus = null }) {
  const D = size;
  const x = useRef(new Animated.Value(0)).current; // deslocamento horizontal
  const pulse = useRef(new Animated.Value(0)).current;
  const spin = useRef(null);
  const current = useRef(0);

  useEffect(() => {
    const id = x.addListener(({ value }) => (current.current = value));
    return () => x.removeListener(id);
  }, [x]);

  const startSpin = () => {
    // normaliza para [-2D, 0] e gira continuamente
    let start = current.current % (2 * D);
    if (start > 0) start -= 2 * D;
    x.setValue(start);
    spin.current = Animated.loop(
      Animated.timing(x, {
        toValue: start - 2 * D,
        duration: 70000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    spin.current.start();
  };

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 1400, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    ).start();
  }, [pulse]);

  useEffect(() => {
    spin.current?.stop();
    if (!focus) {
      startSpin();
      return;
    }
    const px = ((focus.longitude + 180) / 360) * 2 * D; // posição do ponto no mapa
    let target = D / 2 - px;
    if (target > 0) target -= 2 * D;
    Animated.timing(x, {
      toValue: target,
      duration: 1800,
      easing: Easing.inOut(Easing.cubic),
      useNativeDriver: true,
    }).start();
    // eslint-disable-next-line
  }, [focus?.latitude, focus?.longitude]);

  const pinY = focus ? ((90 - focus.latitude) / 180) * D : D / 2;

  return (
    <View style={{ width: D, height: D }}>
      {/* halo atmosférico */}
      <View
        style={[
          styles.halo,
          { width: D * 1.18, height: D * 1.18, borderRadius: D, left: -D * 0.09, top: -D * 0.09 },
        ]}
      />
      <View style={[styles.sphere, { width: D, height: D, borderRadius: D / 2 }]}>
        <Animated.View style={{ flexDirection: 'row', transform: [{ translateX: x }] }}>
          <Image source={{ uri: EARTH }} style={{ width: 2 * D, height: D }} />
          <Image source={{ uri: EARTH }} style={{ width: 2 * D, height: D }} />
        </Animated.View>

        {/* sombra esférica: luz vindo do alto à esquerda */}
        <Svg width={D} height={D} style={StyleSheet.absoluteFill} pointerEvents="none">
          <Defs>
            <RadialGradient id="shade" cx="38%" cy="32%" rx="75%" ry="75%">
              <Stop offset="0" stopColor="#fff" stopOpacity="0.12" />
              <Stop offset="0.55" stopColor="#000" stopOpacity="0.05" />
              <Stop offset="1" stopColor="#000" stopOpacity="0.8" />
            </RadialGradient>
          </Defs>
          <Circle cx={D / 2} cy={D / 2} r={D / 2} fill="url(#shade)" />
        </Svg>

        {focus && (
          <View style={[styles.pinWrap, { left: D / 2 - 14, top: pinY - 14 }]} pointerEvents="none">
            <Animated.View
              style={[
                styles.ring,
                {
                  opacity: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.8, 0] }),
                  transform: [{ scale: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.4, 1.6] }) }],
                },
              ]}
            />
            <View style={styles.dot} />
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  halo: { position: 'absolute', backgroundColor: 'rgba(80,150,255,0.14)' },
  sphere: { overflow: 'hidden', backgroundColor: '#0B2A5B' },
  pinWrap: { position: 'absolute', width: 28, height: 28, alignItems: 'center', justifyContent: 'center' },
  ring: { position: 'absolute', width: 28, height: 28, borderRadius: 14, backgroundColor: '#FFB020' },
  dot: { width: 12, height: 12, borderRadius: 6, backgroundColor: '#FFB020', borderWidth: 2, borderColor: '#fff' },
});
