import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useCheckins } from '../Context/CheckinsContext';

// Distância em km entre dois pontos (fórmula de Haversine)
function distanceKm(a, b) {
  const R = 6371;
  const rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(b.latitude - a.latitude);
  const dLon = rad(b.longitude - a.longitude);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a.latitude)) * Math.cos(rad(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function fmtDistance(km) {
  return km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1)} km`;
}

export default function HistoryScreen({ navigation }) {
  const { checkins, remove, current } = useCheckins();

  if (checkins.length === 0) {
    return (
      <View style={styles.empty}>
        <Text style={styles.emptyTitle}>Nenhum check-in ainda</Text>
        <Text style={styles.emptyBody}>Descubra sua localização e toque em “Salvar check-in”.</Text>
        <Pressable style={styles.btn} onPress={() => navigation.goBack()}>
          <Text style={styles.btnText}>Voltar ao globo</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <FlatList
      style={{ backgroundColor: '#050A18' }}
      contentContainerStyle={{ padding: 16 }}
      data={checkins}
      keyExtractor={(i) => i.id}
      renderItem={({ item }) => (
        <View style={styles.card}>
          <View style={{ flex: 1 }}>
            <Text style={styles.address}>{item.address}</Text>
            <Text style={styles.meta}>
              {item.latitude.toFixed(4)}, {item.longitude.toFixed(4)}
            </Text>
            <Text style={styles.meta}>
              {new Date(item.date).toLocaleString('pt-BR')}
              {current ? `  •  a ${fmtDistance(distanceKm(current, item))} de você` : ''}
            </Text>
          </View>
          <Pressable onPress={() => remove(item.id)} hitSlop={10}>
            <Text style={styles.del}>Excluir</Text>
          </Pressable>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row', alignItems: 'center', padding: 16, marginBottom: 10, borderRadius: 16,
    backgroundColor: '#0B1530', borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)',
  },
  address: { color: '#F2F6FF', fontWeight: '700', fontSize: 15, marginBottom: 4 },
  meta: { color: '#8394B8', fontSize: 12, marginTop: 2 },
  del: { color: '#FF8A8A', fontWeight: '600', marginLeft: 12 },
  empty: { flex: 1, backgroundColor: '#050A18', alignItems: 'center', justifyContent: 'center', padding: 30 },
  emptyTitle: { color: '#F2F6FF', fontSize: 20, fontWeight: '700', marginBottom: 8 },
  emptyBody: { color: '#9FB0D0', textAlign: 'center', marginBottom: 20 },
  btn: { backgroundColor: '#FFB020', paddingHorizontal: 22, paddingVertical: 12, borderRadius: 14 },
  btnText: { color: '#1A1200', fontWeight: '700' },
});