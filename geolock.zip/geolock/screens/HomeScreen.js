import React, { useState } from 'react';
import {
  ActivityIndicator, Dimensions, Linking, Pressable, StyleSheet, Text, View,
} from 'react-native';
import * as Location from 'expo-location';
import Globe from '../components/Globe';
import { useCheckins } from '../Context/CheckinsContext';

const { width, height } = Dimensions.get('window');
const GLOBE = Math.min(width * 1.05, 440);

export default function HomeScreen({ navigation }) {
  const { add, checkins, current, setCurrent } = useCheckins();
  const [loading, setLoading] = useState(false);
  const [denied, setDenied] = useState(false);
  const [error, setError] = useState(null);
  const [saved, setSaved] = useState(false);

  async function locate() {
    setLoading(true); setError(null); setSaved(false);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setDenied(true);
        return;
      }
      setDenied(false);
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const { latitude, longitude, accuracy } = pos.coords;
      let address = 'Endereço não encontrado';
      try {
        const [a] = await Location.reverseGeocodeAsync({ latitude, longitude });
        if (a) {
          address = [a.street, a.district || a.subregion, a.city, a.region, a.country]
            .filter(Boolean).join(', ');
        }
      } catch (e) { /* sem endereço */ }
      setCurrent({ latitude, longitude, accuracy, address });
    } catch (e) {
      setError('Não foi possível obter sua posição. Verifique se o GPS está ligado e tente de novo.');
    } finally {
      setLoading(false);
    }
  }

  function save() {
    add({ id: String(Date.now()), ...current, date: new Date().toISOString() });
    setSaved(true);
  }

  return (
    <View style={styles.container}>
      {STARS.map((s, i) => (
        <View key={i} style={[styles.star, { left: s[0], top: s[1], opacity: s[2] }]} />
      ))}

      <View style={styles.globe}>
        <Globe size={GLOBE} focus={current} />
      </View>

      <View style={styles.top}>
        <Text style={styles.title}>Onde estou?</Text>
        <Pressable onPress={() => navigation.navigate('Historico')} style={styles.chip}>
          <Text style={styles.chipText}>Check-ins ({checkins.length})</Text>
        </Pressable>
      </View>

      <View style={styles.panel}>
        {denied ? (
          <>
            <Text style={styles.heading}>Precisamos da sua permissão</Text>
            <Text style={styles.body}>
              Sem acesso à localização não dá para mostrar onde você está. Libere nas configurações do aparelho.
            </Text>
            <Pressable style={styles.primary} onPress={() => Linking.openSettings()}>
              <Text style={styles.primaryText}>Abrir configurações</Text>
            </Pressable>
            <Pressable style={styles.link} onPress={locate}>
              <Text style={styles.linkText}>Tentar novamente</Text>
            </Pressable>
          </>
        ) : current ? (
          <>
            <Text style={styles.heading}>{current.address}</Text>
            <View style={styles.coords}>
              <Coord label="Latitude" value={current.latitude.toFixed(5)} />
              <Coord label="Longitude" value={current.longitude.toFixed(5)} />
              <Coord label="Precisão" value={`±${Math.round(current.accuracy || 0)} m`} />
            </View>
            <Pressable style={[styles.primary, saved && styles.done]} onPress={save} disabled={saved}>
              <Text style={styles.primaryText}>{saved ? 'Check-in salvo' : 'Salvar check-in'}</Text>
            </Pressable>
            <Pressable style={styles.link} onPress={locate}>
              <Text style={styles.linkText}>{loading ? 'Atualizando…' : 'Atualizar posição'}</Text>
            </Pressable>
          </>
        ) : (
          <>
            <Text style={styles.heading}>Encontre sua posição no planeta</Text>
            <Text style={styles.body}>
              Toque no botão e o globo vai girar até o ponto em que você está.
            </Text>
            <Pressable style={styles.primary} onPress={locate} disabled={loading}>
              {loading ? <ActivityIndicator color="#1A1200" /> : <Text style={styles.primaryText}>Descobrir minha localização</Text>}
            </Pressable>
          </>
        )}
        {error && <Text style={styles.error}>{error}</Text>}
      </View>
    </View>
  );
}

function Coord({ label, value }) {
  return (
    <View style={{ flex: 1 }}>
      <Text style={styles.coordLabel}>{label}</Text>
      <Text style={styles.coordValue}>{value}</Text>
    </View>
  );
}

const STARS = Array.from({ length: 40 }, (_, i) => [
  (i * 97) % width, (i * 151) % height, 0.2 + ((i * 7) % 10) / 15,
]);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#050A18' },
  star: { position: 'absolute', width: 2, height: 2, borderRadius: 1, backgroundColor: '#fff' },
  globe: { position: 'absolute', top: height * 0.1, left: (width - GLOBE) / 2 },
  top: { paddingTop: 56, paddingHorizontal: 22, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { color: '#F2F6FF', fontSize: 28, fontWeight: '700', letterSpacing: -0.5 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.12)' },
  chipText: { color: '#F2F6FF', fontWeight: '600', fontSize: 13 },
  panel: {
    position: 'absolute', left: 14, right: 14, bottom: 28, padding: 20, borderRadius: 24,
    backgroundColor: 'rgba(8,16,38,0.88)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
  },
  heading: { color: '#F2F6FF', fontSize: 18, fontWeight: '700', marginBottom: 8 },
  body: { color: '#9FB0D0', fontSize: 14, lineHeight: 20, marginBottom: 16 },
  coords: { flexDirection: 'row', marginVertical: 12 },
  coordLabel: { color: '#7C8DB0', fontSize: 12, marginBottom: 2 },
  coordValue: { color: '#F2F6FF', fontSize: 15, fontWeight: '600' },
  primary: { backgroundColor: '#FFB020', borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  done: { backgroundColor: '#5BD6A0' },
  primaryText: { color: '#1A1200', fontWeight: '700', fontSize: 15 },
  link: { alignItems: 'center', paddingTop: 14 },
  linkText: { color: '#8FB6FF', fontWeight: '600' },
  error: { color: '#FF8A8A', marginTop: 12, fontSize: 13 },
});